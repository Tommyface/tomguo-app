/* global host, exports */
'use strict';
// 黄豆短剧（huangdou）：AES-CBC + HMAC 签名的加密接口站源模块。
// 站点：https://lzlukvca.cc（备用 momodrift.top / eyeonneb.cc）
//
// 协议（2026-11 实测）：
//   外层  {token, deviceId, data}
//   加密  gzip(JSON) → AES-256-CBC，key = hmacSha256(PLATFORM_KEY, bytes.fromhex(rid 去横线))
//         body = IV(16) || ciphertext，PKCS7 填充值为填充长度本身（不是 0）
//   头签名 sign = md5("Dart|sessionId|requestId|秒级时间|host+path") + "-" + 秒级时间
//   体签名 _sts = 秒级时间；_sig = hmacSha256(SIGN_KEY, "_sts|deviceId|path") 的 hex
//   响应  同样的 key 解密，IV 在前，解出 gzip 后是 JSON
//   必需  line_code = "china_1"；version 头 1.0.0；deviceType 头 web
var BASE = 'https://lzlukvca.cc';
var PLATFORM_KEY = '7961beb44246e3012ce228d6b5ced05a';
var SIGN_KEY = 'b7f3c1e94a2d58f06e1b9c7d3a4f8e255d0c6a9b1e7f42c83d9a0b6e1f4c7a28';
var LINE_CODE = 'china_1';
var UA = 'Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36';
var PAGE_SIZE = 20;
var STORE_TOKEN = 'huangdou.token';
var STORE_DID = 'huangdou.deviceId';
var STORE_SID = 'huangdou.sessionId';

var state = { token: '', deviceId: '', sessionId: '', ready: false };

function bytes(s) { return host.bytes(s); }
function hexToBytes(hex) {
  var out = new Uint8Array(hex.length >> 1);
  for (var i = 0; i < out.length; i++) out[i] = parseInt(hex.substr(i * 2, 2), 16);
  return out;
}
function bytesToHex(b) {
  var s = '';
  for (var i = 0; i < b.length; i++) s += (b[i] < 16 ? '0' : '') + b[i].toString(16);
  return s;
}
function concat(a, b) {
  var out = new Uint8Array(a.length + b.length);
  out.set(a, 0); out.set(b, a.length);
  return out;
}
function pad16(b) {
  var amount = 16 - (b.length % 16);
  var out = new Uint8Array(b.length + amount);
  out.set(b, 0); out.fill(amount, b.length);
  return out;
}
function unpad(b) {
  var n = b[b.length - 1];
  if (n < 1 || n > 16 || n > b.length) return b;
  for (var i = b.length - n; i < b.length; i++) if (b[i] !== n) return b;
  return b.subarray(0, b.length - n);
}
function uuid4() {
  var r = host.randomBytes(16);
  r[6] = (r[6] & 0x0f) | 0x40;
  r[8] = (r[8] & 0x3f) | 0x80;
  var h = bytesToHex(r);
  return h.substr(0, 8) + '-' + h.substr(8, 4) + '-' + h.substr(12, 4) + '-' + h.substr(16, 4) + '-' + h.substr(20, 12);
}
function nowSec() { return String(Math.floor(Date.now() / 1000)); }

function ensureIdentity() {
  if (state.deviceId && state.sessionId) return;
  state.deviceId = String(host.storageGet(STORE_DID) || '') || uuid4();
  if (!host.storageGet(STORE_DID)) host.storageSet(STORE_DID, state.deviceId);
  state.sessionId = String(host.storageGet(STORE_SID) || '') || uuid4().replace(/-/g, '');
  if (!host.storageGet(STORE_SID)) host.storageSet(STORE_SID, state.sessionId);
  state.token = String(host.storageGet(STORE_TOKEN) || '');
}

function deviceInfo() {
  return { browserName: 'BrowserName.chrome', language: 'zh-CN', userAgent: UA, platform: 'Linux x86_64' };
}

// 发送一次加密请求；tokenOverride 用于登录时强制传空 token。
function request(path, data, tokenOverride) {
  ensureIdentity();
  var rid = uuid4();
  var ts = nowSec();
  var ridHex = rid.replace(/-/g, '');
  var sign = bytesToHex(host.md5(bytes('Dart|' + state.sessionId + '|' + rid + '|' + ts + '|' + BASE.replace(/^https?:\/\//, '') + path))) + '-' + ts;

  var body = data;
  if (data && typeof data === 'object') {
    body = {};
    for (var k in data) if (Object.prototype.hasOwnProperty.call(data, k)) body[k] = data[k];
    body._sts = ts;
    body._sig = bytesToHex(host.hmacSha256(bytes(SIGN_KEY), bytes(ts + '|' + state.deviceId + '|' + path)));
  }

  var payload = { token: tokenOverride === undefined ? state.token : tokenOverride, deviceId: state.deviceId, data: body };
  var key = host.hmacSha256(bytes(PLATFORM_KEY), hexToBytes(ridHex));
  var iv = host.randomBytes(16);
  var plain = pad16(host.gzip(bytes(JSON.stringify(payload))));
  var wire = concat(iv, host.aesCbcEncrypt(key, iv, plain));

  var res = host.fetch({
    method: 'POST',
    url: BASE + '/api' + path,
    bodyBase64: host.base64Encode(wire),
    timeoutMs: 25000,
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'User-Agent': UA,
      version: '1.0.0',
      deviceType: 'web',
      time: ts,
      sign: sign,
      requestId: rid,
      sessionId: state.sessionId,
      deviceBrand: '',
      deviceModel: '',
      systemName: '',
      systemVersion: '',
      'X-Lang': 'zh',
      Referer: ''
    }
  });
  if (!res || !res.bodyBase64) throw new Error('黄豆无响应：' + (res ? res.status : 'no response'));
  var raw = host.base64Decode(res.bodyBase64);
  if (raw.length <= 32 || (raw.length - 16) % 16 !== 0) {
    // 服务端错误时直接回明文 JSON
    try { return JSON.parse(host.utf8(raw)); } catch (e) { throw new Error('黄豆响应无法解析'); }
  }
  var dec = unpad(host.aesCbcDecrypt(key, raw.subarray(0, 16), raw.subarray(16)));
  var text;
  try { text = host.utf8(host.gunzip(dec)); } catch (e) { text = host.utf8(dec); }
  return JSON.parse(text);
}

function login() {
  ensureIdentity();
  var r = request('/login/device', {
    line_code: LINE_CODE,
    channel_code: '',
    share_code: '',
    clipboard_text: '',
    force_new: '',
    device_info: deviceInfo()
  }, '');
  var d = r && r.data;
  if (!d || !d.token) throw new Error('黄豆登录失败：' + ((r && r.error) || '未返回 token'));
  state.token = String(d.token);
  host.storageSet(STORE_TOKEN, state.token);
  state.ready = true;
  return d;
}

function call(path, data) {
  if (!state.ready && !state.token) login();
  var r = request(path, data);
  if (r && r.status === 'n') {
    var code = Number(r.errorCode);
    // token 失效（401/2001 类）时重登一次
    if (code === 401 || code === 4001 || code === 4003 || code === 2001) {
      state.token = ''; state.ready = false;
      host.storageSet(STORE_TOKEN, '');
      login();
      r = request(path, data);
    }
  }
  if (r && r.status === 'n') throw new Error('黄豆接口错误：' + (r.error || '未知') + (r.errorCode ? ' (' + r.errorCode + ')' : ''));
  return r && r.data !== undefined ? r.data : r;
}

function absUrl(raw) {
  var s = String(raw || '').trim();
  if (!s) return '';
  if (/^https?:\/\//i.test(s)) return s;
  if (/^\/\//.test(s)) return 'https:' + s;
  return BASE + (s.charAt(0) === '/' ? '' : '/') + s;
}
function num(v) { var n = parseInt(String(v == null ? '' : v), 10); return isNaN(n) ? 0 : n; }

// 列表项 → 统一剧目结构。drama_id 形如 self_xxx / rp_xxx，detail 只认去掉前缀后的 id 字段。
function toDrama(row) {
  if (!row) return null;
  var raw = String(row.drama_id || row.id || '').trim();
  if (!raw) return null;
  var shortId = String(row.id || '').trim() || raw.replace(/^[a-z]+_/i, '');
  var title = String(row.name || row.title || '').trim();
  if (!title) return null;
  var cover = absUrl(row.img || row.cover || row.image || '');
  var tags = [];
  if (row.category) tags.push(String(row.category));
  if (row.corner) tags.push(String(row.corner));
  (Array.isArray(row.honor_tags) ? row.honor_tags : []).forEach(function (t) {
    var s = typeof t === 'string' ? t : (t && (t.name || t.title)) || '';
    if (s && tags.length < 8) tags.push(String(s));
  });
  var eps = num(row.episode_count);
  return {
    id: 'huangdou:' + shortId,
    source: 'huangdou',
    sourceId: shortId,
    title: title,
    description: String(row.description || ''),
    cover: cover,
    episodes: eps,
    totalEpisode: eps,
    episodeCount: eps,
    category: tags[0] || '短剧',
    tags: tags
  };
}

function pickList(data) {
  if (!data) return [];
  if (Array.isArray(data)) return data;
  if (Array.isArray(data.list)) return data.list;
  if (Array.isArray(data.items)) return data.items;
  if (Array.isArray(data.data)) return data.data;
  return [];
}

exports.categories = async function () {
  return [
    { id: 'feed', name: '推荐' },
    { id: 'short', name: '短剧' },
    { id: 'long', name: '长剧' },
    { id: 'all', name: '全部' }
  ];
};

exports.catalogPage = async function (page, category) {
  var p = Math.max(1, num(page) || 1);
  var cat = String(category || 'feed');
  var rows = [];
  var hasMore = false;

  if (cat === 'feed') {
    // 首页 feed 用 block 递增分页，每块 20 条
    var d = call('/v2/drama/mix', {
      scene: 'feed',
      session: 'feed1_' + state.sessionId.slice(0, 11),
      block: String(p - 1),
      refresh: p === 1 ? '1' : '0',
      personal_off: '0'
    });
    rows = pickList(d);
    hasMore = rows.length >= PAGE_SIZE;
  } else {
    var body = { page: String(p), page_size: String(PAGE_SIZE) };
    if (cat === 'short') body.canvas = 'short';
    if (cat === 'long') body.canvas = 'long';
    var r = call('/v2/drama/list', body);
    rows = pickList(r);
    var total = num(r && r.total);
    hasMore = rows.length >= PAGE_SIZE && (total === 0 || p * PAGE_SIZE < total);
  }

  var items = [];
  rows.forEach(function (row) {
    var d = toDrama(row);
    if (d) items.push(d);
  });
  return { items: items, hasMore: hasMore };
};

exports.search = async function (page, query) {
  var q = String(query || '').trim();
  if (!q) return { items: [], hasMore: false };
  var p = Math.max(1, num(page) || 1);
  var r = call('/v2/drama/list', { keywords: q, page: String(p) });
  var rows = pickList(r);
  var items = [];
  rows.forEach(function (row) {
    var d = toDrama(row);
    if (d) items.push(d);
  });
  return { items: items, hasMore: rows.length >= PAGE_SIZE };
};

exports.detail = async function (sourceId) {
  var id = String(sourceId || '').trim().replace(/^huangdou:/i, '');
  if (!id) throw new Error('黄豆缺少剧集 ID');
  var d = call('/drama/detail', { id: id });
  if (!d) throw new Error('黄豆详情为空');
  var eps = Array.isArray(d.episodes) ? d.episodes : [];
  var chapters = eps.map(function (e, i) {
    var seq = num(e.seq) || i + 1;
    var rawName = String(e.name || '').trim();
    var label = /^第/.test(rawName) ? rawName : ('第' + seq + '集');
    return {
      id: 'huangdou:' + id + ':' + seq,
      title: label,
      name: label,
      index: seq,
      videoUrl: '',
      currentEpisode: seq,
      locked: String(e.type || '') === 'vip' && !e.bought
    };
  });
  var tags = [];
  if (d.category) tags.push(String(d.category));
  (Array.isArray(d.tags) ? d.tags : []).forEach(function (t) {
    var s = typeof t === 'string' ? t : (t && (t.name || t.title)) || '';
    if (s && tags.length < 10) tags.push(String(s));
  });
  var cover = absUrl(d.img_x || d.img || '');
  var drama = {
    id: 'huangdou:' + id,
    source: 'huangdou',
    sourceId: id,
    title: String(d.name || d.title || '').trim(),
    description: String(d.description || ''),
    cover: cover,
    category: tags[0] || '短剧',
    tags: tags,
    episodes: num(d.episode_count) || chapters.length,
    totalEpisode: num(d.episode_count) || chapters.length,
    episodeCount: chapters.length
  };
  return { drama: drama, chapters: chapters };
};

exports.resolveMedia = async function (task) {
  var t = task || {};
  var chapter = t.chapter || {};
  var sourceId = String(t.sourceId || t.dramaId || '').trim().replace(/^huangdou:/i, '');
  var seq = num(chapter.currentEpisode) || num(chapter.index) || 1;
  if (!sourceId) {
    // 从 chapter.id 兜底解析 huangdou:<dramaId>:<seq>
    var cid = String(chapter.id || '').trim();
    var parts = cid.split(':');
    if (parts.length >= 3) {
      sourceId = parts[1];
      seq = num(parts[2]) || seq;
    }
  }
  if (!sourceId) throw new Error('黄豆缺少剧集参数');

  var d = call('/drama/play', { id: sourceId, episode: seq });
  var lines = (d && Array.isArray(d.lines)) ? d.lines : [];
  var url = String((d && d.m3u8) || '');
  if (!url && lines.length) url = String(lines[0].url || '');
  if (!url) throw new Error('黄豆未返回播放地址');
  var headers = { 'User-Agent': UA, Referer: BASE + '/' };
  return {
    url: url,
    headers: headers,
    media: { url: url, headers: headers, type: 'hls' },
    lines: lines.map(function (l) {
      return { name: String(l.name || ''), url: String(l.url || '') };
    })
  };
};
