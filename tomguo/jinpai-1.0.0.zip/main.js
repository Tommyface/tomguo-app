'use strict';
// 金牌影视（jiabaide.cn）：匿名接口 + 服务端渲染详情。
// 签名 = sha1(hex(md5(数据串 + "&key=" + KEY + "&t=" + 毫秒时间戳)))
// 宿主 API 全同步，禁用 Promise / setTimeout。

var SITE = 'https://www.jiabaide.cn';
var SIGN_KEY = 'cb808529bae6b6be45ecfab29a4889bc';
var UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36';

var TABS = [
  { id: '1', name: '电影' },
  { id: '2', name: '电视剧' },
  { id: '3', name: '综艺' },
  { id: '4', name: '动漫' },
];

function hex(bytes) {
  var out = '';
  for (var i = 0; i < bytes.length; i++) {
    var value = bytes[i] & 0xff;
    out += (value < 16 ? '0' : '') + value.toString(16);
  }
  return out;
}

function uuid() {
  var bytes = host.randomBytes(16);
  bytes[6] = (bytes[6] & 0x0f) | 0x40;
  bytes[8] = (bytes[8] & 0x3f) | 0x80;
  var text = hex(bytes);
  return text.slice(0, 8) + '-' + text.slice(8, 12) + '-' + text.slice(12, 16) + '-' +
    text.slice(16, 20) + '-' + text.slice(20, 32);
}

function signedHeaders(signSource) {
  var t = Date.now();
  var md5Hex = hex(host.md5(signSource + '&key=' + SIGN_KEY + '&t=' + t));
  var sign = hex(host.sha1(host.bytes(md5Hex)));
  return { 'User-Agent': UA, deviceId: uuid(), t: String(t), sign: sign };
}

function apiGet(path, signSource, label) {
  var res = host.fetch({
    url: SITE + path,
    headers: signedHeaders(signSource),
    followRedirects: true,
    timeoutMs: 15000,
  });
  if (res.status !== 200) throw new Error((label || '接口') + '暂时不可用（HTTP ' + res.status + '）');
  var payload = JSON.parse(res.body);
  if (!payload || Number(payload.code) !== 200) {
    throw new Error((label || '接口') + '返回异常：' + ((payload && payload.msg) || '未知'));
  }
  return payload.data;
}

function cardOf(row, categoryName) {
  if (!row || row.vodId == null) return null;
  var title = String(row.vodName || '').trim();
  if (!title || title.indexOf('预告') >= 0) return null;
  var card = {
    id: host.dramaId(String(row.vodId)),
    source: host.source,
    sourceId: String(row.vodId),
    title: title,
    cover: row.vodPic || '',
  };
  if (row.vodRemarks) card.status = String(row.vodRemarks).split('|')[0].slice(0, 12);
  if (categoryName) card.category = categoryName;
  var pubdate = parseInt(String(row.vodPubdate || ''), 10);
  if (isFinite(pubdate) && pubdate > 1900) card.year = pubdate;
  return card;
}

function pageOf(value) {
  var n = parseInt(value || '1', 10);
  return n > 0 ? n : 1;
}

module.exports = {
  categories: function () {
    return TABS.map(function (item) { return { id: item.id, name: item.name }; });
  },

  catalogPage: function (page, category) {
    var tabId = category && String(category).trim() ? String(category) : '1';
    var tabName = '电影';
    for (var i = 0; i < TABS.length; i++) {
      if (TABS[i].id === tabId) tabName = TABS[i].name;
    }
    var qs = 'area=&filterStatus=1&lang=&pageNum=' + pageOf(page) + '&pageSize=30&sort=1&sortBy=1&type=&type1=' +
      encodeURIComponent(tabId) + '&v_class=&year=';
    var data = apiGet('/api/mw-movie/anonymous/video/list?' + qs, qs, '列表');
    var rows = (data && data.list) || [];
    var items = [];
    for (var j = 0; j < rows.length; j++) {
      var card = cardOf(rows[j], tabName);
      if (card) items.push(card);
    }
    return { items: items, hasMore: rows.length >= 30 };
  },

  detail: function (sourceId) {
    var id = String(sourceId || '').trim();
    if (!id) throw new Error('缺少作品标识');
    var res = host.fetch({
      url: SITE + '/detail/' + encodeURIComponent(id),
      headers: { 'User-Agent': UA },
      followRedirects: true,
      timeoutMs: 20000,
    });
    if (res.status !== 200) throw new Error('详情暂时不可用（HTTP ' + res.status + '）');
    var html = res.body || '';
    var titleMatch = html.match(/<title>([^<]+)<\/title>/);
    var title = titleMatch ? titleMatch[1].replace(/[-_|].*$/, '').trim() : ('作品' + id);
    var coverMatch = html.match(/"vodPic":"([^"]+)"/);
    var chapters = [];
    var seen = {};
    var pattern = /\\"nid\\":(\d+),\\"name\\":\\"([^"\\]*)\\"/g;
    var match;
    while ((match = pattern.exec(html)) !== null) {
      var nid = match[1];
      var label = match[2] || '';
      if (seen[nid]) continue;
      seen[nid] = true;
      var seq = chapters.length + 1;
      chapters.push({
        id: host.chapterId(id, nid),
        source: host.source,
        title: label || ('第' + seq + '集'),
        currentEpisode: seq,
      });
    }
    var drama = {
      id: host.dramaId(id),
      source: host.source,
      sourceId: id,
      title: title,
      cover: coverMatch ? coverMatch[1] : '',
    };
    if (chapters.length) drama.totalEpisode = chapters.length;
    return { drama: drama, chapters: chapters };
  },

  resolveMedia: function (task) {
    var dramaId = String((task && task.dramaId) || '');
    var sourceId = dramaId.indexOf(':') >= 0 ? dramaId.split(':')[1] : dramaId;
    var chapterId = String((task && task.chapter && task.chapter.id) || '');
    var nid = '';
    if (chapterId) {
      var parts = chapterId.split(':');
      nid = parts.length >= 3 ? parts[2] : '';
    }
    if (!sourceId || !nid) throw new Error('缺少播放参数');
    var qs = 'id=' + encodeURIComponent(sourceId) + '&nid=' + encodeURIComponent(nid);
    var data = apiGet('/api/mw-movie/anonymous/v2/video/episode/url?' + qs, qs, '播放');
    var rows = (data && data.list) || [];
    var picked = '';
    for (var i = 0; i < rows.length; i++) {
      if (rows[i] && rows[i].url) { picked = rows[i].url; break; }
    }
    if (!picked) throw new Error('该集暂时取不到播放地址');
    return { url: picked, referer: SITE + '/' };
  },
};
