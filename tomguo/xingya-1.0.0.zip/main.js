'use strict';
// 星芽短剧：设备号匿名登录换 JWT，之后接口带 authorization。
// 宿主 API 全同步，禁用 Promise / setTimeout。令牌缓存在 host.storage。

var SITE = 'https://app.whjzjx.cn';
var LOGIN = 'https://u.shytkjgs.com/user/v1/account/login';
var DEVICE_ID = '2885ce2d34c9634b287ab022f2f3a6cfb';

var CATEGORIES = [
  { id: '2', name: '推荐' },
  { id: '3', name: '都市' },
  { id: '4', name: '古装' },
  { id: '5', name: '悬疑' },
  { id: '6', name: '甜宠' },
];

function baseHeaders() {
  return {
    'User-Agent': 'okhttp/4.10.0',
    'x-app-id': '7',
    platform: '1',
    manufacturer: 'asus',
    version_name: '3.3.1',
    app_version: '3.3.1',
    device_platform: 'android',
    device_type: 'Zenfone+5Z',
    device_brand: 'asus',
    os_version: '14',
    channel: 'default',
    raw_channel: 'default',
    uuid: 'randomUUID_9e91d3ce-8658-4d6e-9d1b-6f351611163d',
    device_id: DEVICE_ID,
    support_h265: '1',
    user_agent:
      'Mozilla/5.0 (Linux; Android 14; Zenfone 5Z Build/AP2A.240705.005; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/125.0.6422.165 Mobile Safari/537.36',
  };
}

function storageGet(key) {
  return typeof host.storageGet === 'function' ? (host.storageGet(key) || '') : '';
}

function storageSet(key, value, ttlSec) {
  if (typeof host.storageSet === 'function') host.storageSet(key, value, ttlSec);
}

function token() {
  var cached = storageGet('token');
  if (cached) return cached;
  var headers = baseHeaders();
  headers['Content-Type'] = 'application/x-www-form-urlencoded';
  var res = host.fetch({
    method: 'POST',
    url: LOGIN,
    headers: headers,
    body: 'device=' + encodeURIComponent(DEVICE_ID),
    timeoutMs: 15000,
  });
  if (res.status !== 200) throw new Error('星芽登录失败（HTTP ' + res.status + '）');
  var payload = JSON.parse(res.body);
  var fresh = payload && payload.data && payload.data.token;
  if (!fresh) throw new Error('星芽登录返回结构已变化');
  storageSet('token', fresh, 6 * 24 * 3600);
  return fresh;
}

function authHeaders() {
  var headers = baseHeaders();
  headers.authorization = token();
  return headers;
}

function signedHeaders(url) {
  var headers = authHeaders();
  var q = String(url || '');
  var i = q.indexOf('?');
  var query = i >= 0 ? q.slice(i + 1) : '';
  var ts = String(Date.now());
  headers.timestamp = ts;
  headers.sign = host.md5(query + ts);
  return headers;
}

function getJson(url, label) {
  var res = host.fetch({ url: url, headers: signedHeaders(url), timeoutMs: 20000 });
  if (res.status !== 200) throw new Error((label || '接口') + '暂时不可用（HTTP ' + res.status + '）');
  var payload = JSON.parse(res.body);
  if (!payload || payload.code !== 'ok') {
    throw new Error((label || '接口') + '返回异常：' + ((payload && payload.msg) || '未知'));
  }
  return payload.data;
}

function cardOf(raw) {
  if (!raw || raw.id == null) return null;
  var title = String(raw.title || '').trim();
  if (!title) return null;
  var card = {
    id: host.dramaId(String(raw.id)),
    source: host.source,
    sourceId: String(raw.id),
    title: title,
    cover: raw.cover_url || '',
  };
  if (raw.total) card.totalEpisode = Number(raw.total);
  if (raw.introduction) card.desc = String(raw.introduction);
  return card;
}

function pageOf(value) {
  var n = parseInt(value || '1', 10);
  return n > 0 ? n : 1;
}

module.exports = {
  categories: function () {
    return CATEGORIES.map(function (item) { return { id: item.id, name: item.name }; });
  },

  catalogPage: function (page, category) {
    var classId = category && String(category).trim() ? String(category) : '2';
    var data = getJson(
      SITE + '/cloud/v2/theater/home_page?theater_class_id=' + encodeURIComponent(classId) +
        '&type=1&page_num=' + pageOf(page) + '&page_size=24',
      '列表'
    );
    var rows = (data && data.list) || [];
    var items = [];
    for (var i = 0; i < rows.length; i++) {
      var card = cardOf(rows[i] && rows[i].theater);
      if (card) items.push(card);
    }
    return { items: items, hasMore: rows.length >= 24 };
  },

  search: function (page, query) {
    var keyword = String(query || '').trim();
    if (!keyword) return { items: [], hasMore: false };
    var headers = signedHeaders('');
    headers['Content-Type'] = 'application/json';
    var res = host.fetch({
      method: 'POST',
      url: SITE + '/v3/search',
      headers: headers,
      body: JSON.stringify({ text: encodeURIComponent(keyword) }),
      timeoutMs: 15000,
    });
    if (res.status !== 200) throw new Error('搜索暂时不可用（HTTP ' + res.status + '）');
    var payload = JSON.parse(res.body);
    if (!payload || payload.code !== 'ok') return { items: [], hasMore: false };
    var bucket = (payload.data && payload.data.theater) || {};
    var rows = bucket.search_data || [];
    var items = [];
    for (var i = 0; i < rows.length; i++) {
      var card = cardOf(rows[i]);
      if (card) items.push(card);
    }
    if (!items.length && bucket.recommend_data) {
      for (var j = 0; j < bucket.recommend_data.length && j < 6; j++) {
        var fallback = cardOf(bucket.recommend_data[j]);
        if (fallback) items.push(fallback);
      }
      return { items: items, hasMore: false, warning: '没有精确匹配，下面是相关推荐' };
    }
    return { items: items, hasMore: false };
  },

  detail: function (sourceId) {
    var id = String(sourceId || '').trim();
    if (!id) throw new Error('缺少作品标识');
    var data = getJson(SITE + '/v2/theater_parent/detail?theater_parent_id=' + encodeURIComponent(id), '详情');
    var theaters = (data && data.theaters) || [];
    var drama = cardOf({
      id: data && data.id, title: data && data.title, cover_url: data && data.cover_url,
      total: data && data.total, introduction: data && data.introduction,
    }) || { id: host.dramaId(id), source: host.source, sourceId: id, title: '短剧' + id };
    drama.id = host.dramaId(id);
    drama.sourceId = id;
    if (data && data.vip === 1) drama.vip = true;
    var chapters = [];
    for (var i = 0; i < theaters.length; i++) {
      var num = Number(theaters[i].num);
      if (!isFinite(num) || num <= 0) num = i + 1;
      chapters.push({
        id: host.chapterId(id, String(num)),
        source: host.source,
        title: '第' + num + '集',
        currentEpisode: num,
      });
    }
    return { drama: drama, chapters: chapters };
  },

  resolveMedia: function (task) {
    var dramaId = String((task && task.dramaId) || '');
    var sourceId = dramaId.indexOf(':') >= 0 ? dramaId.split(':')[1] : dramaId;
    var seq = Number(task && task.chapter && task.chapter.currentEpisode) || 1;
    var data = getJson(SITE + '/v2/theater_parent/detail?theater_parent_id=' + encodeURIComponent(sourceId), '播放');
    var theaters = (data && data.theaters) || [];
    var picked = '';
    for (var i = 0; i < theaters.length; i++) {
      if (Number(theaters[i].num) === seq) { picked = theaters[i].son_video_url; break; }
    }
    if (!picked && theaters.length) picked = theaters[0].son_video_url;
    if (!picked) throw new Error('该集暂时取不到播放地址');
    return { url: picked, referer: SITE + '/' };
  },
};
