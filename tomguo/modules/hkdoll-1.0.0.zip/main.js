// 玩偶姐姐站源模块。
// 列表：<div class="video-item"><div class="thumb"><a title="…" href="/video/<id>.html"><img src=…>
// 详情页里有一行 var __PAGE__PARAMS__="<hex>"：
//   末 32 个字符是 XOR 密钥，前面是 hex 密文，解出来是 JSON，player.embedUrl 是播放嵌入页。
//   embed 页的 token 拆两半：末 10 位做 md5，取 md5 的 8..24 反转当 XOR 密钥，前半段解出 {"stream": "<m3u8>"}。
// 本网络对该域名有 DNS 污染，所以每个请求都先 DoH 拿真实 IP，再钉上去。

const SITE = "https://hongkongdollvideo.com";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const ipCache = {};
const PINNED_IPS = ["172.67.175.6", "104.21.80.67"];

function ipFor(domain) {
  if (Object.prototype.hasOwnProperty.call(ipCache, domain)) return ipCache[domain];
  let ips = PINNED_IPS.slice();
  try {
    const list = host.resolveDNS(domain);
    if (list && list.length > 0) {
      for (let index = 0; index < list.length; index++) {
        const ip = String(list[index]);
        if (ips.indexOf(ip) < 0) ips.push(ip);
      }
    }
  } catch (error) {}
  ipCache[domain] = ips;
  return ips;
}

function hostOf(url) {
  const match = /^https?:\/\/([^\/]+)/i.exec(url);
  return match ? match[1] : "";
}

function requestHeaders(referer) {
  return {
    "User-Agent": UA,
    Accept: "text/html,application/xhtml+xml",
    "Accept-Language": "zh-CN,zh;q=0.9",
    Referer: referer || SITE + "/",
  };
}

function get(url) {
  const domain = hostOf(url);
  const ips = domain ? ipFor(domain) : [];
  let lastError = null;
  for (let index = 0; index < ips.length; index++) {
    try {
      const response = host.fetch({
        url: url,
        headers: requestHeaders(SITE + "/"),
        resolveIP: ips[index],
        timeoutMs: 25000,
      });
      const status = Number(response.status || 0);
      if (status >= 200 && status < 300) return String(response.body || "");
      lastError = new Error("玩偶姐姐 HTTP " + status);
    } catch (error) {
      lastError = error;
    }
  }
  try {
    const response = host.fetch({
      url: url,
      headers: requestHeaders(SITE + "/"),
      timeoutMs: 25000,
    });
    const status = Number(response.status || 0);
    if (status >= 200 && status < 300) return String(response.body || "");
    lastError = new Error("玩偶姐姐 HTTP " + status);
  } catch (error) {
    lastError = error;
  }
  throw lastError instanceof Error ? lastError : new Error("玩偶姐姐请求失败");
}

function unescapeHTML(text) {
  return String(text || "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\\\//g, "/");
}

function absolute(href) {
  const value = String(href || "").trim();
  if (value === "") return "";
  if (/^https?:\/\//i.test(value)) return value;
  if (value.indexOf("//") === 0) return "https:" + value;
  return value.charAt(0) === "/" ? SITE + value : SITE + "/" + value;
}

// 列表项：<div class="video-item"><div class="thumb"><a title="标题" href="/video/ID.html">
//   <img src="封面"></a></div><div class="video-info"><a class="video-title" …>标题</a>
const ITEM = /<div class="video-item">[\s\S]*?<\/div>\s*<\/div>\s*<\/div>/gi;
const ITEM_FALLBACK = /<div class="video-item">[\s\S]*?<div class="video-info">[\s\S]*?<\/div>\s*<\/div>/gi;

function parseCards(html) {
  const items = [];
  const seen = {};
  const blocks = html.match(ITEM) || html.match(ITEM_FALLBACK) || [];
  for (let index = 0; index < blocks.length; index++) {
    const block = blocks[index];
    const link = /<a[^>]+class="video-title"[^>]*>([\s\S]*?)<\/a>|<a[^>]+href="([^"]+)"[^>]*title="([^"]*)"/i.exec(block);
    const href = /href="([^"]*\/video\/[^"]+)"/i.exec(block);
    if (!href) continue;
    const url = absolute(unescapeHTML(href[1]));
    const idMatch = /\/video\/([a-z0-9]+)\.html/i.exec(url);
    if (!idMatch) continue;
    const sourceId = idMatch[1];
    if (seen[sourceId]) continue;
    seen[sourceId] = true;

    let title = "";
    const titleAttr = /class="video-title"[^>]*title="([^"]*)"/i.exec(block);
    if (titleAttr) title = unescapeHTML(titleAttr[1]);
    if (title === "") {
      const alt = /<img[^>]+alt="([^"]*)"/i.exec(block);
      if (alt) title = unescapeHTML(alt[1]);
    }
    if (title === "" && link) {
      const raw = link[1] || link[3] || "";
      title = unescapeHTML(String(raw).replace(/<[^>]+>/g, ""));
    }
    title = String(title).trim();
    if (title === "") continue;

    let cover = "";
    const img = /<img[^>]+>/i.exec(block);
    if (img) {
      const dataSrc = /data-src="([^"]+)"/i.exec(img[0]);
      const src = /src="([^"]+)"/i.exec(img[0]);
      cover = absolute(unescapeHTML(dataSrc ? dataSrc[1] : src ? src[1] : ""));
    }
    let badge = "";
    const date = /<div class="date">([^<]*)<\/div>/i.exec(block);
    if (date) badge = unescapeHTML(date[1]).trim().slice(0, 12);

    items.push({
      id: host.dramaId(sourceId),
      source: host.source,
      sourceId: sourceId,
      title: title,
      name: title,
      cover: cover,
      badge: badge,
      totalEpisode: 1,
      episodeCount: 1,
      category: "玩偶姐姐",
    });
  }
  return items;
}

function sourceIdOf(dramaId) {
  const text = String(dramaId || "");
  const prefix = host.source + ":";
  if (text.indexOf(prefix) !== 0) return "";
  return text.slice(prefix.length);
}

function hexOf(bytes) {
  let out = "";
  for (let index = 0; index < bytes.length; index++) {
    const value = bytes[index] & 0xff;
    out += (value < 16 ? "0" : "") + value.toString(16);
  }
  return out;
}

function xorHex(hex, key) {
  let out = "";
  for (let index = 0; index + 1 < hex.length; index += 2) {
    const code = parseInt(hex.substr(index, 2), 16);
    const shift = key.charCodeAt(Math.floor(index / 2) % key.length);
    out += String.fromCharCode(code ^ shift);
  }
  return out;
}

function decodePageParams(html) {
  const match = /__PAGE__PARAMS__="([^"]+)"/.exec(html);
  if (!match) throw new Error("玩偶姐姐未找到页面参数");
  const param = match[1];
  if (param.length < 40) throw new Error("玩偶姐姐页面参数过短");
  const key = param.slice(-32);
  const body = param.slice(0, param.length - 32);
  let text = "";
  try {
    text = xorHex(body, key);
    return JSON.parse(text);
  } catch (error) {
    throw new Error("玩偶姐姐页面参数无法解析");
  }
}

function decodeStream(embedUrl) {
  const mark = embedUrl.indexOf("?token=");
  if (mark < 0) throw new Error("玩偶姐姐播放地址缺少 token");
  const token = embedUrl.slice(mark + "?token=".length);
  if (token.length < 20) throw new Error("玩偶姐姐 token 过短");
  const tail = token.slice(-10);
  const md5 = hexOf(host.md5(tail));
  const key = md5.slice(8, 24).split("").reverse().join("");
  const body = token.slice(0, token.length - 10);
  let payload = null;
  try {
    payload = JSON.parse(xorHex(body, key));
  } catch (error) {
    throw new Error("玩偶姐姐播放参数解密失败");
  }
  const stream = payload && payload.stream ? String(payload.stream) : "";
  if (stream === "") throw new Error("玩偶姐姐没有下发播放地址");
  return stream;
}

module.exports = {
  categories() {
    return [{ id: "", name: "最新" }];
  },

  catalogPage(page, category) {
    const base = String(category || "").trim() || SITE + "/latest/";
    let url = base;
    if (page > 1) url = base.replace(/\/+$/, "/") + page + ".html";
    const items = parseCards(get(url));
    return { items: items, hasMore: items.length > 0 };
  },

  search(page, query) {
    const keyword = String(query || "").trim();
    if (keyword === "") return { items: [], hasMore: false };
    let url = SITE + "/search/" + encodeURIComponent(keyword) + "/";
    if (page > 1) url = url + page + ".html";
    const items = parseCards(get(url));
    return { items: items, hasMore: items.length > 0 };
  },

  detail(sourceId) {
    const id = String(sourceId || "").trim();
    if (!/^[a-z0-9]+$/i.test(id)) throw new Error("玩偶姐姐作品 ID 无效");
    const url = SITE + "/video/" + id + ".html";
    const html = get(url);

    let title = "";
    const h1 = /<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(html);
    if (h1) title = unescapeHTML(h1[1]).replace(/<[^>]+>/g, "").trim();
    if (title === "") {
      const docTitle = /<title>([\s\S]*?)<\/title>/i.exec(html);
      title = unescapeHTML(docTitle ? docTitle[1] : "").split("-")[0].trim();
    }
    if (title === "") title = id;

    let cover = "";
    const thumb = /<img[^>]+src="([^"]*\/uploads\/[^"]*)"/i.exec(html);
    if (thumb) cover = absolute(unescapeHTML(thumb[1]));

    let desc = "";
    const meta = /<meta name="description" content="([^"]*)"/i.exec(html);
    if (meta) desc = unescapeHTML(meta[1]).trim();

    const drama = {
      id: host.dramaId(id),
      source: host.source,
      sourceId: id,
      title: title,
      name: title,
      desc: desc,
      intro: desc,
      cover: cover,
      totalEpisode: 1,
      episodeCount: 1,
      category: "玩偶姐姐",
    };
    const chapters = [
      {
        id: host.chapterId(id, "1"),
        source: host.source,
        title: "播放",
        currentEpisode: 1,
      },
    ];
    return { drama: drama, chapters: chapters };
  },

  resolveMedia(task) {
    let id = sourceIdOf(task && task.dramaId);
    if (id === "" && task && task.chapter) {
      id = sourceIdOf(String(task.chapter.id || "").replace(/:\d+$/, ""));
    }
    if (!/^[a-z0-9]+$/i.test(id)) throw new Error("玩偶姐姐分集 ID 无效");
    const html = get(SITE + "/video/" + id + ".html");
    const params = decodePageParams(html);
    const embedUrl = params && params.player && params.player.embedUrl ? String(params.player.embedUrl) : "";
    if (embedUrl === "") throw new Error("玩偶姐姐未找到播放嵌入地址");
    const url = decodeStream(embedUrl);
    return { url: url, referer: SITE + "/" };
  },
};
