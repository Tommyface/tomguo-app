// 黄果官网站源模块 v1.2.0
//
// 接口契约来自 hghub-clone（HGhub 1.2.0 复刻）实测：
//   列表   GET  /api/videos?page=N            每页 20 条，全量 3361 部 / 169 页
//   搜索   GET  /api/search?q=X&page=N        keyword 参数返回空，q 才是对的
//   详情   GET  /api/videos/{id}              返回 episodes / episode_count
//   播放   POST /api/videos/{id}/episodes/{ep}/playback
//          请求体必须是空 JSON {}，带 id/ep 会被判「播放参数无效」
//          响应 data.streams.main 是该集 HLS 清单，任意一集都能取
//
// 站点在中国大陆被 DNS 污染（huangguoai.com 解析到 31.13.x），
// 所以这里做多入口轮换：自己的 Worker → 官方三域名 → cloudfront app 接口。

// 你自己的 Cloudflare Worker 地址，排在官方域名前面。
// 大陆直连 huangguoai.com 会被 DNS 污染，把 Worker 地址填进来即可绕过：
//   const WORKER_BASES = ["https://xxx.workers.dev", "https://yyy.workers.dev"];
// 实测：workers.dev 的 HTTPS(443) 在部分网络被 SNI 阻断，但 HTTP(80) 通，
// 所以这里用 http 前缀。内容是公开的剧集元数据，明文传输可接受。
// 实测：workers.dev 的 HTTP(80) 通；自定义域名在部分网络被 SNI 阻断。
// workers.dev 排第一，自定义域名作后备（换网络环境可能反过来）。
const WORKER_BASES = [
  "http://hghub-api.gyqingfengxulai.workers.dev",
  "https://hg1.tommyfac.ccwu.cc",
  "https://hg3.tommyfac.ccwu.cc",
  "https://api.tommyfac.ccwu.cc",
];

// 播放地址的 CDN（hzjvlo.cn / drleao.cn）在大陆也不通时，把流地址改写成走 Worker 的
// /p?url= 代理。先保持 false；播不了再改 true。
const PROXY_MEDIA = false;

const WEB_BASES = [
  "https://huangguoai.com",
  "https://huangguoai.ai",
  "https://huangguoai.io",
];

// 旧的 app 接口：响应是 AES-256-CBC 加密 envelope，搜索参数是 keyword。
const APP_BASE = "https://dqsibjrdsxx5r.cloudfront.net/api/app/officialWebsite";
const INTERFACE_KEY = "65dc07d1b7915c6b2937432b091837a7";

const IMAGE_CDN = "https://zzzznnn.lkkwip.cn";
const UA =
  "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/120 Mobile Safari/537.36";

// ---------- 基础工具 ----------

function concat() {
  let total = 0;
  for (let i = 0; i < arguments.length; i++) total += arguments[i].length;
  const out = new Uint8Array(total);
  let offset = 0;
  for (let i = 0; i < arguments.length; i++) {
    out.set(arguments[i], offset);
    offset += arguments[i].length;
  }
  return out;
}

function unpad(bytes) {
  if (bytes.length === 0) return bytes;
  const pad = bytes[bytes.length - 1];
  if (pad < 1 || pad > 16 || pad > bytes.length) return bytes;
  return bytes.slice(0, bytes.length - pad);
}

function raw(url, options) {
  const settings = options || {};
  const headers = Object.assign(
    {
      "User-Agent": UA,
      Accept: "application/json, text/plain, */*",
      "Accept-Language": "zh-CN,zh;q=0.9",
    },
    settings.headers || {},
  );
  const match = /^https?:\/\/([^/?#:]+)/i.exec(url);
  const hostname = match ? match[1] : "";
  const pinned = hostname === "" ? "" : realIP(hostname);
  const request = {
    method: settings.method || "GET",
    url,
    headers,
    body: settings.body === undefined ? "" : settings.body,
    timeoutMs: settings.timeoutMs || 20000,
  };
  if (pinned !== "" && pinned !== hostname) request.resolveIP = pinned;
  return host.fetch(request);
}

// DoH 解析缓存：本地 DNS 被污染时，用真实 IP 直连（Host 头与 SNI 仍是原域名）。
const dnsCache = {};

function realIP(hostname) {
  if (dnsCache[hostname] !== undefined) return dnsCache[hostname];
  let ip = "";
  try {
    const list = host.resolveDNS(hostname);
    if (list && list.length > 0) ip = list[0];
  } catch (error) {
    ip = "";
  }
  dnsCache[hostname] = ip;
  return ip;
}

function getJSON(url, options) {
  const settings = options || {};
  const response = raw(url, {
    method: settings.method,
    headers: settings.headers,
    body: settings.body,
    timeoutMs: settings.timeoutMs || 4000,
  });
  if (response.status < 200 || response.status >= 300) {
    throw new Error("HTTP " + response.status);
  }
  const text = response.body;
  if (text === "") throw new Error("响应为空");
  try {
    return JSON.parse(text);
  } catch (error) {
    throw new Error("响应不是 JSON");
  }
}

function postJSON(url, payload) {
  return getJSON(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload === undefined ? {} : payload),
  });
}

// ---------- 多入口轮换 ----------
// 每个操作都按顺序试入口，第一个成功的胜出并记住，下次先用它。

let webBase = "";
// 连续失败的入口在本进程内跳过，避免每次操作都白等一遍超时。
const deadBases = {};

function webBases() {
  const list = [];
  for (const base of WORKER_BASES) list.push(String(base).replace(/\/+$/, ""));
  for (const base of WEB_BASES) list.push(base);
  const alive = list.filter(function (base) {
    return !deadBases[base];
  });
  if (alive.length > 0) list.length = 0, list.push.apply(list, alive);
  // 上次成功的排最前。
  if (webBase !== "") {
    const index = list.indexOf(webBase);
    if (index > 0) {
      list.splice(index, 1);
      list.unshift(webBase);
    }
  }
  return list;
}

// webCall 依次尝试各入口，返回第一个成功的结果。
function webCall(build) {
  let lastError = null;
  for (const base of webBases()) {
    try {
      const result = build(base);
      webBase = base;
      delete deadBases[base];
      return result;
    } catch (error) {
      lastError = error;
      const message = String(error && error.message ? error.message : error);
      // 只有连不上才判死；业务层错误（比如 404）不封入口。
      if (/HTTP \d{3}|为空|不是 JSON|不可用|超时|timeout/i.test(message) === false) {
        deadBases[base] = true;
      }
    }
  }
  throw lastError || new Error("黄果官网全部入口不可用");
}

// ---------- app 接口：AES-256-CBC envelope ----------

function appDecrypt(payload) {
  const data = host.base64Decode(payload);
  if (data.length < 13) throw new Error("响应过短");
  const key = host.bytes(INTERFACE_KEY);
  const combined = concat(key, data.slice(0, 12));
  const half = combined.length >> 1;
  const seed = host.sha256(combined);
  const keySeed = seed.slice(8, 24);
  const left = concat(keySeed, combined.slice(0, half));
  const right = concat(combined.slice(half), keySeed);
  const p = host.sha256(left);
  const h = host.sha256(right);
  const aesKey = concat(p.slice(0, 8), h.slice(8, 24), p.slice(24, 32));
  const iv = concat(h.slice(0, 4), p.slice(12, 20), h.slice(28, 32));
  return JSON.parse(host.utf8(unpad(host.aesCbcDecrypt(aesKey, iv, data.slice(12)))));
}

function appRequest(path) {
  const envelope = getJSON(APP_BASE + path);
  let data = envelope.data;
  if (envelope.hash === true && typeof data === "string") data = appDecrypt(data);
  return { code: Number(envelope.code), data, msg: envelope.msg };
}

// ---------- 字段归一 ----------

const SUFFIX = /[-—_]\s*(?:guangguo|huangguo)\.(?:com|ai|io)\s*$/i;

function cleanTitle(value) {
  let title = String(value || "").trim();
  title = title.replace(SUFFIX, "");
  title = title.replace(/第\s*[0-9]+\s*[集话話]\s*[｜|].*$/, "");
  title = title.replace(/\s*EP\s*[0-9]+.*$/i, "");
  return title.trim() || String(value || "").trim();
}

function coverURL(value) {
  const text = String(value || "").trim();
  if (text === "") return "";
  if (/^https?:\/\//i.test(text)) return text;
  return IMAGE_CDN + "/" + text.replace(/^\/+/, "");
}

function intOr(value, fallback) {
  const parsed = parseInt(String(value === undefined || value === null ? "" : value), 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

// 上游字段名不统一：id / video_id，episode_count / total_episodes。
function toDrama(row) {
  if (!row || typeof row !== "object") return null;
  const sourceId = String(row.id || row.video_id || row.seoSlug || row.slug || "").trim();
  if (sourceId === "") return null;
  const title = cleanTitle(row.title || row.name || sourceId);
  let total = intOr(row.episode_count, 0);
  if (total <= 0) total = intOr(row.total_episodes, 0);
  if (total <= 0) total = intOr(row.totalEpisode, 0);
  const author = row.author && typeof row.author === "object" ? row.author.name : row.author;
  const drama = {
    id: host.dramaId(sourceId),
    source: host.source,
    sourceId,
    title,
    name: title,
    desc: String(row.description || row.intro || ""),
    intro: String(row.description || row.intro || ""),
    cover: coverURL(row.cover || row.cover_url || row.pic),
    totalEpisode: total,
    episodeCount: total,
    category: String(row.category || row.category_name || "黄果官网"),
    author: String(author || ""),
  };
  return drama;
}

function itemsOf(payload) {
  if (!payload) return [];
  if (Array.isArray(payload)) return payload;
  for (const key of ["items", "list", "records", "videos", "results"]) {
    if (Array.isArray(payload[key])) return payload[key];
  }
  if (payload.data !== undefined && payload.data !== null) return itemsOf(payload.data);
  return [];
}

function dramaList(rows) {
  const out = [];
  for (const row of rows) {
    const drama = toDrama(row);
    if (drama) out.push(drama);
  }
  return out;
}

// 分集序号字段各家不同，取第一个能解析出正整数的。
function episodeNumber(entry, index) {
  for (const key of ["ep", "ep_num", "episode", "episode_number", "number", "index", "sort"]) {
    const value = intOr(entry[key], 0);
    if (value > 0) return value;
  }
  return index + 1;
}

// ---------- 对外接口 ----------

module.exports = {
  categories() {
    return [{ id: "", name: "全部" }];
  },

  catalogPage(page) {
    const current = Math.max(1, intOr(page, 1));
    let rows = [];
    let error = null;
    // 有 Worker 时直接走 Worker；没有时才先用快的 app 接口兜底。
    if (webBase === "" && WORKER_BASES.length === 0) {
      try {
        const result = appRequest("/video/list?pageNumber=" + current + "&pageSize=20");
        if (result.code === 200) rows = itemsOf(result.data);
      } catch (failure) {
        error = failure;
      }
    }
    if (rows.length === 0) {
      try {
        rows = webCall(function (base) {
          const payload = getJSON(base + "/api/videos?page=" + current);
          return itemsOf(payload);
        });
      } catch (failure) {
        if (!error) error = failure;
      }
    }
    if (rows.length === 0) {
      // web 接口不通时退回 app 接口。
      try {
        const result = appRequest("/video/list?pageNumber=" + current + "&pageSize=20");
        if (result.code === 200) rows = itemsOf(result.data);
      } catch (failure) {
        if (!error) error = failure;
      }
    }
    if (rows.length === 0 && error) throw error;
    return { items: dramaList(rows), hasMore: rows.length >= 20 };
  },

  search(page, query) {
    const keyword = String(query || "").trim();
    if (keyword === "") return { items: [], hasMore: false };
    const current = Math.max(1, intOr(page, 1));
    const encoded = encodeURIComponent(keyword);

    let rows = [];
    let error = null;
    if (webBase === "" && WORKER_BASES.length === 0) {
      // app 接口的搜索参数是 keyword，传 q 会得到 code:4001。
      try {
        const result = appRequest(
          "/search?keyword=" + encoded + "&pageNumber=" + current + "&pageSize=20",
        );
        if (result.code === 200) rows = itemsOf(result.data);
      } catch (failure) {
        error = failure;
      }
    }
    if (rows.length === 0) {
      try {
        rows = webCall(function (base) {
          const payload = getJSON(
            base + "/api/search?q=" + encoded + "&page=" + current,
          );
          return itemsOf(payload);
        });
      } catch (failure) {
        if (!error) error = failure;
      }
    }
    if (rows.length === 0 && webBase === "" && WORKER_BASES.length === 0) {
      try {
        const result = appRequest(
          "/search?keyword=" + encoded + "&pageNumber=" + current + "&pageSize=20",
        );
        if (result.code === 200) rows = itemsOf(result.data);
      } catch (failure) {
        if (!error) error = failure;
      }
    }
    if (rows.length === 0 && error) throw error;
    return { items: dramaList(rows), hasMore: rows.length >= 20 };
  },

  detail(sourceId) {
    const id = String(sourceId || "").trim();
    if (id === "") throw new Error("黄果官网剧集 ID 为空");

    let row = null;
    let error = null;
    try {
      row = webCall(function (base) {
        const payload = getJSON(base + "/api/videos/" + encodeURIComponent(id));
        const body = payload && payload.data !== undefined ? payload.data : payload;
        if (!body || typeof body !== "object") throw new Error("详情为空");
        return body;
      });
    } catch (failure) {
      error = failure;
    }
    if (!row) {
      try {
        const result = appRequest("/video/" + encodeURIComponent(id));
        if (result.code === 200 && result.data) row = result.data;
      } catch (failure) {
        if (!error) error = failure;
      }
    }
    if (!row) throw error || new Error("黄果官网详情不可用");

    const drama = toDrama(row) || {
      id: host.dramaId(id),
      source: host.source,
      sourceId: id,
      title: id,
    };

    const episodes = Array.isArray(row.episodes) ? row.episodes : [];
    let total = intOr(drama.episodeCount, 0);
    if (total <= 0) total = episodes.length;
    if (total <= 0) total = intOr(row.freeEpisodeCount, 0);
    if (total <= 0) throw new Error("黄果官网未提供分集");
    if (total > 10000) throw new Error("黄果官网返回了无效集数: " + total);

    const chapters = [];
    for (let index = 0; index < total; index++) {
      const entry = episodes[index];
      const seq = entry ? episodeNumber(entry, index) : index + 1;
      const chapter = {
        id: host.chapterId(id, String(seq)),
        source: host.source,
        title: "第" + seq + "集",
        currentEpisode: seq,
      };
      if (entry && entry.is_free === false) chapter.vip = true;
      chapters.push(chapter);
    }

    drama.totalEpisode = chapters.length;
    drama.episodeCount = chapters.length;
    return { drama, chapters };
  },

  resolveMedia(task) {
    const parts = String(task && task.dramaId ? task.dramaId : "").split(":");
    const id = parts.length > 1 ? parts[1] : "";
    const seq = intOr(task && task.chapter ? task.chapter.currentEpisode : 0, 1);
    if (id === "") throw new Error("黄果官网剧集 ID 无效");

    let error = null;
    // 主路径：POST 空 JSON 取该集流。请求体带 id/ep 会被判「播放参数无效」。
    try {
      const streams = webCall(function (base) {
        const payload = postJSON(
          base +
            "/api/videos/" +
            encodeURIComponent(id) +
            "/episodes/" +
            seq +
            "/playback",
          {},
        );
        const body = payload && payload.data !== undefined ? payload.data : payload;
        const value = (body && body.streams) || {};
        if (!value.main && !value.hevc && !value.preview) {
          throw new Error("播放响应没有 streams");
        }
        return value;
      });
      const url = String(streams.main || streams.hevc || streams.preview || "").trim();
      if (url !== "") {
        return { url: mediaProxy(url), referer: webBase + "/" };
      }
    } catch (failure) {
      error = failure;
    }

    // 兜底：app 接口只下发首集地址。
    try {
      const result = appRequest("/video/" + encodeURIComponent(id));
      if (result.code === 200 && result.data) {
        const episodes = Array.isArray(result.data.episodes) ? result.data.episodes : [];
        for (let index = 0; index < episodes.length; index++) {
          const entry = episodes[index];
          if (!entry) continue;
          const url = String(entry.url || "").trim();
          if (url === "") continue;
          // app 接口的分集顺序就是集数，按序号匹配（章节 id 是模块自己合成的）。
          if (episodeNumber(entry, index) !== seq) continue;
          return { url: mediaURL(url), referer: "https://falpius.com/" };
        }
      }
    } catch (failure) {
      if (!error) error = failure;
    }

    throw error || new Error("黄果官网未下发该集播放地址");
  },
};

// mediaProxy 在 PROXY_MEDIA 打开时把媒体地址改写成 Worker 转发。
function mediaProxy(url) {
  if (!PROXY_MEDIA) return url;
  const base = webBase !== "" ? webBase : WORKER_BASES[0];
  if (!base) return url;
  return String(base).replace(/\/+$/, "") + "/p?url=" + encodeURIComponent(url);
}

function mediaURL(value) {
  const text = String(value || "").trim();
  if (text === "") return "";
  if (/^https?:\/\//i.test(text)) return text;
  return "https://dqsibjrdsxx5r.cloudfront.net/api/app/vid/h5/m3u8/" + text.replace(/^\/+/, "");
}
