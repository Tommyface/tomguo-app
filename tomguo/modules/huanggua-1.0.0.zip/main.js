// 黄瓜短剧站源模块。
// 入口域名 hgdja2.com 只是导航页，真正的站在 ycwzusvz.cc 的三个子域上。
// 页面是服务端渲染：列表卡片与详情分集都在 HTML 里，播放地址内嵌 m3u8。

const SITES = [
  "https://mkqjue.ycwzusvz.cc",
  "https://porncz.ycwzusvz.cc",
  "https://rixgqa.ycwzusvz.cc",
];
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/120 Safari/537.36";

let site = SITES[0];

function get(path) {
  const target = path.indexOf("http") === 0 ? path : site + path;
  const response = host.fetch({
    url: target,
    headers: {
      "User-Agent": UA,
      Accept: "text/html,application/xhtml+xml",
      "Accept-Language": "zh-CN,zh;q=0.9",
      Referer: site + "/",
    },
    timeoutMs: 30000,
  });
  if (response.status < 200 || response.status >= 300) {
    throw new Error("黄瓜短剧 HTTP " + response.status);
  }
  return response.body;
}

// 主域不通时换镜像；同一个错误不重试两次。
function call(path) {
  let lastError = null;
  for (const candidate of [site].concat(SITES)) {
    site = candidate;
    try {
      return get(path);
    } catch (error) {
      lastError = error;
    }
  }
  throw lastError || new Error("黄瓜短剧全部镜像不可用");
}

function unescapeHTML(text) {
  return String(text || "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

// 列表卡片：<a class="hg-drama-card__cover-link" href="/video/ID/"><img ... data-src="封面" alt="标题">
// 同卡片内的 <span class="hg-drama-card__episode">全N集</span> 给出总集数。
const CARD = /class="hg-drama-card__cover-link" href="\/video\/(\d+)\/"><img[^>]*?data-src="([^"]*)"[^>]*?alt="([^"]*)"/g;
const EPISODES = /hg-drama-card__episode">全(\d+)集</g;

function parseCards(html) {
  const episodes = [];
  let match;
  EPISODES.lastIndex = 0;
  while ((match = EPISODES.exec(html)) !== null) episodes.push(parseInt(match[1], 10));

  const items = [];
  CARD.lastIndex = 0;
  let index = 0;
  while ((match = CARD.exec(html)) !== null) {
    const id = match[1];
    const title = unescapeHTML(match[3]).trim();
    const total = episodes[index] || 0;
    index++;
    items.push({
      id: host.dramaId(id),
      source: host.source,
      sourceId: id,
      title: title || id,
      name: title || id,
      cover: unescapeHTML(match[2]),
      totalEpisode: total,
      episodeCount: total,
      category: "黄瓜短剧",
    });
  }
  return items;
}

module.exports = {
  categories() {
    return [{ id: "", name: "全部" }];
  },

  catalogPage(page) {
    const html = call("/newest?page=" + Math.max(1, page));
    const items = parseCards(html);
    return { items, hasMore: items.length > 0 };
  },

  search(page, query) {
    const keyword = String(query || "").trim();
    if (keyword === "") return { items: [], hasMore: false };
    const html = call("/search/?keyword=" + encodeURIComponent(keyword));
    return { items: parseCards(html), hasMore: false };
  },

  detail(sourceId) {
    const id = String(sourceId || "").trim();
    if (!/^\d+$/.test(id)) throw new Error("黄瓜短剧剧集 ID 无效");
    const html = call("/video/" + id + "/");

    const totalMatch = html.match(/data-track-total-episode="(\d+)"/);
    const titleMatch = html.match(/data-track-drama-title="([^"]*)"/);
    const coverMatch = html.match(/<meta property="og:image" content="([^"]*)"/);
    const descMatch = html.match(/<meta name="description" content="([^"]*)"/);

    let total = totalMatch ? parseInt(totalMatch[1], 10) : 0;
    if (total <= 0) {
      const ids = [];
      const re = new RegExp("/video/" + id + "/ep-(\\d+)/", "g");
      let match;
      while ((match = re.exec(html)) !== null) ids.push(parseInt(match[1], 10));
      total = ids.length > 0 ? Math.max.apply(null, ids) : 1;
    }
    if (total <= 0 || total > 10000) throw new Error("黄瓜短剧返回了无效集数");

    const title = unescapeHTML(titleMatch ? titleMatch[1] : "").trim() || id;
    const drama = {
      id: host.dramaId(id),
      source: host.source,
      sourceId: id,
      title,
      name: title,
      desc: unescapeHTML(descMatch ? descMatch[1] : ""),
      intro: unescapeHTML(descMatch ? descMatch[1] : ""),
      cover: unescapeHTML(coverMatch ? coverMatch[1] : ""),
      totalEpisode: total,
      episodeCount: total,
      category: "黄瓜短剧",
    };

    // 第 1 集在 /video/{id}/，第 2 集起在 /video/{id}/ep-{n}/。
    const chapters = [];
    for (let seq = 1; seq <= total; seq++) {
      chapters.push({
        id: host.chapterId(id, String(seq)),
        source: host.source,
        title: "第" + seq + "集",
        currentEpisode: seq,
      });
    }
    return { drama, chapters };
  },

  resolveMedia(task) {
    const parts = String(task && task.dramaId ? task.dramaId : "").split(":");
    const id = parts.length > 1 ? parts[1] : "";
    const seq = parseInt(String((task.chapter && task.chapter.currentEpisode) || 0), 10);
    if (!/^\d+$/.test(id) || !(seq > 0)) throw new Error("黄瓜短剧分集参数无效");

    const path = seq === 1 ? "/video/" + id + "/" : "/video/" + id + "/ep-" + seq + "/";
    const html = call(path);
    const match = html.match(/https?:\/\/[^"'\s\\]+\.m3u8[^"'\s\\]*/);
    if (!match) throw new Error("黄瓜短剧未在该页下发播放地址");
    // HTML 里的 &amp; 与 \\u0026 都要还原成真正的查询分隔符。
    const url = unescapeHTML(match[0].replace(/\\u0026/g, "&")).replace(/&amp;/g, "&");
    return { url, referer: site + "/" };
  },
};
