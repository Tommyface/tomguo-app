// 麻豆社站源模块。
// 站点是 WordPress 主题（excerpts-wrapper / article.excerpt），列表与搜索都是服务端渲染。
// 详情页正文里有一个 iframe 指向 dash.madou.club/share/<id>，播放页里有两个变量：
//   var token = "<JWT>";  var m3u8 = "/videos/<id>/index.m3u8";
// 拼成 https://dash.madou.club/videos/<id>/index.m3u8?token=<JWT> 就是 HLS 清单。
// 本网络对该域名有 DNS 污染，所以每个请求都先 DoH 拿真实 IP，再钉上去。

const SITE = "https://madou.club";
const UA =
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

const ipCache = {};
const PINNED_IPS = {
  "madou.club": ["172.67.73.139", "104.26.0.177", "104.26.1.177"],
  "dash.madou.club": ["104.26.0.177", "104.26.1.177", "172.67.73.139"],
};

function ipFor(domain) {
  if (Object.prototype.hasOwnProperty.call(ipCache, domain)) return ipCache[domain];
  let ips = PINNED_IPS[domain] || [];
  if (ips.length === 0) {
    try {
      const list = host.resolveDNS(domain);
      if (list && list.length > 0) ips = list.map(function (item) { return String(item); });
    } catch (error) {
      ips = [];
    }
  }
  ipCache[domain] = ips;
  return ips;
}

function hostOf(url) {
  const match = /^https?:\/\/([^\/]+)/i.exec(url);
  return match ? match[1] : "";
}

function headers(extra) {
  const base = {
    "User-Agent": UA,
    Accept: "text/html,application/xhtml+xml",
    "Accept-Language": "zh-CN,zh;q=0.9",
    Referer: SITE + "/",
  };
  if (extra) {
    for (const key in extra) {
      if (Object.prototype.hasOwnProperty.call(extra, key)) base[key] = extra[key];
    }
  }
  return base;
}

function get(url) {
  const domain = hostOf(url);
  const ips = domain ? ipFor(domain) : [];
  let lastError = null;
  for (let index = 0; index < ips.length; index++) {
    try {
      const response = host.fetch({
        url: url,
        headers: headers(),
        resolveIP: ips[index],
        timeoutMs: 25000,
      });
      const status = Number(response.status || 0);
      if (status >= 200 && status < 300) return String(response.body || "");
      lastError = new Error("麻豆社 HTTP " + status);
    } catch (error) {
      lastError = error;
    }
  }
  try {
    const response = host.fetch({ url: url, headers: headers(), timeoutMs: 25000 });
    const status = Number(response.status || 0);
    if (status >= 200 && status < 300) return String(response.body || "");
    lastError = new Error("麻豆社 HTTP " + status);
  } catch (error) {
    lastError = error;
  }
  throw lastError instanceof Error ? lastError : new Error("麻豆社请求失败");
}

function unescapeHTML(text) {
  return String(text || "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\\\//g, "/")
    .replace(/&#(\d+);/g, function (all, code) {
      return String.fromCharCode(parseInt(code, 10));
    });
}

function absolute(href) {
  const value = String(href || "").trim();
  if (value === "") return "";
  if (/^https?:\/\//i.test(value)) return value;
  if (value.indexOf("//") === 0) return "https:" + value;
  return value.charAt(0) === "/" ? SITE + value : SITE + "/" + value;
}

// 列表项：<article class="excerpt ..."><a class="thumbnail" href="URL"><img data-src="封面">
//   <h2><a href="URL">标题</a></h2><footer>…<span class="post-view">观看(1.2K)</span></footer></article>
const ARTICLE = /<article[^>]*class="[^"]*excerpt[^"]*"[\s\S]*?<\/article>/gi;

function parseCards(html) {
  const items = [];
  let match;
  ARTICLE.lastIndex = 0;
  while ((match = ARTICLE.exec(html)) !== null) {
    const block = match[0];
    const href = /<a[^>]+href="([^"]+)"/i.exec(block);
    if (!href) continue;
    const url = absolute(unescapeHTML(href[1]));
    let title = "";
    const h2 = /<h2[^>]*>([\s\S]*?)<\/h2>/i.exec(block);
    if (h2) {
      const inner = /<a[^>]*>([\s\S]*?)<\/a>/i.exec(h2[1]);
      title = unescapeHTML(inner ? inner[1] : h2[1]);
    }
    if (title === "") {
      const alt = /<img[^>]+alt="([^"]*)"[^>]*>/i.exec(block);
      title = unescapeHTML(alt ? alt[1] : "");
    }
    title = String(title).replace(/<[^>]+>/g, "").trim();
    if (title === "") continue;

    let cover = "";
    const img = /<img[^>]+>/i.exec(block);
    if (img) {
      const dataSrc = /data-src="([^"]+)"/i.exec(img[0]);
      const src = /src="([^"]+)"/i.exec(img[0]);
      cover = unescapeHTML(dataSrc ? dataSrc[1] : src ? src[1] : "");
      cover = absolute(cover);
    }
    let badge = "";
    const view = /<span class="post-view">([^<]*)<\/span>/i.exec(block);
    if (view) badge = unescapeHTML(view[1]).trim().slice(0, 12);

    items.push({
      id: host.dramaId(url),
      source: host.source,
      sourceId: url,
      title: title,
      name: title,
      cover: cover,
      badge: badge,
      totalEpisode: 1,
      episodeCount: 1,
      category: "麻豆社",
    });
  }
  return items;
}

function sourceIdOf(dramaId) {
  const text = String(dramaId || "");
  const prefix = host.source + ":";
  if (text.indexOf(prefix) !== 0) return "";
  return text.slice(prefix.length);
}

function pageUrl(base, page) {
  if (page <= 1) return base;
  return base.replace(/\/+$/, "") + "/page/" + page;
}

function playInfo(pageHtml) {
  const embed = /<iframe[^>]+src=["']?(https?:\/\/[^"'\s>]+)/i.exec(pageHtml);
  if (!embed) throw new Error("麻豆社未找到播放框");
  const embedUrl = embed[1];
  const playerHTML = get(embedUrl);
  const tokenMatch = /var token = "([^"]*)"/.exec(playerHTML);
  const m3u8Match = /var m3u8 = '([^']*)'/.exec(playerHTML);
  if (!tokenMatch || !m3u8Match) throw new Error("麻豆社播放参数缺失");
  const token = tokenMatch[1].trim();
  const path = m3u8Match[1].trim();
  if (path === "") throw new Error("麻豆社没有下发播放路径");
  const origin = "https://" + hostOf(embedUrl);
  let url = path.indexOf("http") === 0 ? path : origin + (path.charAt(0) === "/" ? path : "/" + path);
  if (token !== "") url = url + (url.indexOf("?") >= 0 ? "&" : "?") + "token=" + token;
  return { url, origin };
}

module.exports = {
  categories() {
    return [{ id: "", name: "全部" }];
  },

  catalogPage(page, category) {
    const base = String(category || "").trim() || SITE + "/";
    const items = parseCards(get(pageUrl(base, page)));
    return { items: items, hasMore: items.length > 0 };
  },

  search(page, query) {
    const keyword = String(query || "").trim();
    if (keyword === "") return { items: [], hasMore: false };
    const url = SITE + "/page/" + page + "/?s=" + encodeURIComponent(keyword);
    const items = parseCards(get(url));
    return { items: items, hasMore: items.length > 0 };
  },

  detail(sourceId) {
    const url = String(sourceId || "").trim();
    if (!/^https?:\/\//i.test(url)) throw new Error("麻豆社作品地址无效");
    const html = get(url);

    let title = "";
    const h1 = /<h1[^>]*>([\s\S]*?)<\/h1>/i.exec(html);
    if (h1) title = unescapeHTML(h1[1]).replace(/<[^>]+>/g, "").trim();
    if (title === "") {
      const docTitle = /<title>([\s\S]*?)<\/title>/i.exec(html);
      title = unescapeHTML(docTitle ? docTitle[1] : "").split("-")[0].trim();
    }
    if (title === "") title = url;

    let cover = "";
    const thumb = /<img[^>]+(?:data-src|src)="([^"]*(?:covers|uploads)[^"]*)"/i.exec(html);
    if (thumb) cover = absolute(unescapeHTML(thumb[1]));

    let desc = "";
    const meta = /<meta name="description" content="([^"]*)"/i.exec(html);
    if (meta) desc = unescapeHTML(meta[1]).trim();

    const drama = {
      id: host.dramaId(url),
      source: host.source,
      sourceId: url,
      title: title,
      name: title,
      desc: desc,
      intro: desc,
      cover: cover,
      totalEpisode: 1,
      episodeCount: 1,
      category: "麻豆社",
    };
    const chapters = [
      {
        id: host.chapterId(url, "1"),
        source: host.source,
        title: "播放",
        currentEpisode: 1,
      },
    ];
    return { drama: drama, chapters: chapters };
  },

  resolveMedia(task) {
    let url = sourceIdOf(task && task.dramaId);
    if (url === "" && task && task.chapter) {
      url = sourceIdOf(String(task.chapter.id || "").replace(/:\d+$/, ""));
    }
    if (!/^https?:\/\//i.test(url)) throw new Error("麻豆社分集地址无效");
    const info = playInfo(get(url));
    return { url: info.url, referer: info.origin + "/" };
  },
};
